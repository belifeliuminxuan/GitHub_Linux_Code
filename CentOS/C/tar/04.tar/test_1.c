/**********************************************************
 * Author   : liuminxuan
 * Email    : liuminxuan1024@163.com
 * Time     : 2020-02-21 17:01
 * FileName : test_1.c
 * *******************************************************/

#include <stdio.h>
#include <ctype.h>

int main()
{
  printf ("%c",tolower('A'));


  return 0;
}
