/**********************************************************
 * Author   : liuminxuan
 * Email    : liuminxuan1024@163.com
 * Time     : 2020-02-21 08:25
 * FileName : main.c
 * *******************************************************/

#include <stdio.h>

int main()
{

  _Bool test = True;
  while (test)
  {
    ;
  }
  return 0;
}
