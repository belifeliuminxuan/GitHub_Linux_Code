/**********************************************************
 * Author   : liuminxuan
 * Email    : liuminxuan1024@163.com
 * Time     : 2020-02-21 09:57
 * FileName : test.c
 * *******************************************************/
#include <stdio.h>
#include <stdint.h>
#include <inttypes.h>
int main()
{

  //printf ("\a");

  //printf ("1");
 




  return 0;
}
