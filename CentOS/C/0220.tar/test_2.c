/**********************************************************
 * Author   : liuminxuan
 * Email    : liuminxuan1024@163.com
 * Time     : 2020-02-20 21:04
 * FileName : test_2.c
 * *******************************************************/

#include <stdio.h>

int main()
{

  printf ("请输入英寸值:");
  float inch;
  scanf("%f",&inch);
  printf ("转换后为:%f",inch*2.54);
  return 0;
}
