 ###########################################################
 # Author   : liuminxuan
 # Email    : liuminxuan1024@163.com
 # Time     : 2020-02-20 21:09
 # FileName : create.sh
 ###########################################################


 read FileName
 touch $FileName
 echo "创建成功!"
